# Chat Program using TCP Sockets

This assignment deals with creating a chat-server program using TCP sockets. Also,
we learned how to use I/O multiplexing to achieve concurrency in data processing

Please see a4.pdf for more information.

