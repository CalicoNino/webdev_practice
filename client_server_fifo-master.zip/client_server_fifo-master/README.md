# A chat program using FIFOs

This assignment deals with developing client-server programs using named Pipes for communication.
In addition, file locking is learned for controlling access to the available FIFOs.

Please see a2.pdf for more information.

