sudo resources/nmapAutomator.sh -H $1 --type All -o "results/$1/nmapautomator"
